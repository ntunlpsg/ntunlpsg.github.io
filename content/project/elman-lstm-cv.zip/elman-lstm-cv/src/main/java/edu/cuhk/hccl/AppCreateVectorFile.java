package edu.cuhk.hccl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class AppCreateVectorFile {
	
	public static final String SEPERATOR = "\t";
	
	private static WordEmbedding embedLoader = null;

	public static void main(String[] args) throws IOException {

		System.out.println("Processing is started...");

		String dataFile = args[0];
		String embeddingFile = args[1];
		String type = args[2];
		String vecFile = args[3];
		
		// Load the word embeddings for all words in the vocabulary
		embedLoader = Utility.loadWordEmbedding(type, embeddingFile);
		
		// Create files
		createCRFfile(dataFile, vecFile);

		System.out.println("Processing is finished!");
	}

	public static void createCRFfile(String dataFile, String vecFile) throws IOException{

		List<String> dataLines = FileUtils.readLines(new File(dataFile));
		List<String> vecLines = new ArrayList<String>();
		
		for (String line : dataLines){
			if (line.isEmpty())
				vecLines.add(line);
			else{
				String[] tmpArray = line.split(SEPERATOR);
				if (tmpArray != null){
					String word = tmpArray[0].trim().toLowerCase();
					String wordVec = getWordEmbedding(word);
					
					String label = tmpArray[2].trim();
					vecLines.add(label + SEPERATOR + wordVec);	
				}
			}
		}
		
		FileUtils.writeLines(new File(vecFile), vecLines, false);
	}

	private static String getWordEmbedding(String word) {
		
		float[] wordEmbed = embedLoader.getWordEmbedding(word);
		if (wordEmbed==null)
			wordEmbed = embedLoader.getWordEmbedding(Utility.UNKNOWN);
		
		StringBuffer features = new StringBuffer();
		
		for (int i = 0; i < wordEmbed.length; i++){
			String feature = String.format("v[%d]=v%d:%.6f%s", i, i, wordEmbed[i], SEPERATOR);
			features.append(feature);
		}
		
		String wordVec = features.toString().trim();
		return wordVec;
	}
	
}