package edu.cuhk.hccl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.apache.commons.io.FileUtils;

public class AppCRFFileStatistics {
	
	public static final String SEPERATOR = "\t";

	public static void main(String[] args) throws IOException {

		System.out.println("Processing is started...");

		String dataFile = args[0];
		
		List<String> dataLines = FileUtils.readLines(new File(dataFile));
		List<Integer> counterList = new ArrayList<Integer>();
		Queue<String> termQueue = new LinkedList<String>();
		
		for (String line : dataLines) {
			if (!line.isEmpty()) {
				String[] tmpArray = line.split(SEPERATOR);
				String label = tmpArray[2].trim();
				if (label.startsWith("B") || label.startsWith("I")) {
					termQueue.add(label);
				}
			}
		}
	
		int termLength = 1;
		while(!termQueue.isEmpty()){
			String peak = termQueue.remove();
			
			if (peak.startsWith("B")){
				counterList.add(termLength);
				termLength = 1;
			} else
				termLength += 1;
		}
		
		int totalLength = 0;
		for (int counter : counterList )
			totalLength += counter;
		
		double average = totalLength * 1.0 / counterList.size();

		System.out.println("[INFO] Average length is :" + average);
		System.out.println("[INFO] Number of terms is :" + counterList.size());
		
		System.out.println("Processing is finished!");
	}
	
}