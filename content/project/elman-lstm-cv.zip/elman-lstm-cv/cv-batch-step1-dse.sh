dataset=$1
embed=$2
dim=$3
hidden=$4

if [ "$embed" == "Google" ]; then
    file=embeddings/google-news/GoogleNews-vectors-negative300.bin.gz
elif [ "$embed" == "Amazon" ]; then
    file=embeddings/amazon/vectors-${dim}.txt
else
    file=embeddings/senna
fi

mkdir -p cv-result cv-${dataset} ${dataset}
for fold in {0..9}
do
    make run-convertor dataset=${dataset} fold=${fold}
    mvn -q compile exec:java -Dexec.mainClass=edu.cuhk.hccl.AppPrepareRnnJson \
	-Dexec.args="-t ${dataset}/train${fold}.tsv -r 0.9 -s ${dataset}/test${fold}.tsv -o ${dataset}-json-${embed}.txt -e ${file} -p ${embed} -v ${dataset}/valid${fold}.tsv"
    mv ${dataset}-json-${embed}.txt ${dataset}-json-${embed}-${fold}.txt
    python main.py ${dataset}-json-${embed}-${fold}.txt elman ${dataset}-elman-${embed}-3-${hidden}-${dim}-${fold} 3 ${hidden} ${dim} true > cv-${dataset}/${embed}-${dim}-${hidden}-${fold}.log &
done

