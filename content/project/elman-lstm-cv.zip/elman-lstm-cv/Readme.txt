About
=====
This package contains all the source code for the paper named "Extracting Opinion Targets from Reviews by Recurrent Neural Network and Word Embeddings".
All the experiments in the paper can be reproduced by running the commands in the Makefile or the shell scripts, e.g., "sh batch-crfsuite.sh" or "sh rnn-batch Senna".

Prerequisite
============
To run the scripts, the datasets and some open source tools need to be downloaded:
(1) Datasets from SemEval-2014 Task 4: http://alt.qcri.org/semeval2014/task4/index.php?id=data-and-tools
(2) word2vec and Google News Embeddings: https://code.google.com/p/word2vec/
(3) Amazon Reviews: https://snap.stanford.edu/data/web-Amazon.html
(4) SENNA Embeddings: http://ronan.collobert.com/senna/

Third-Party Toolkits
====================
(1) We revised the RNN implementation from Grégoire Mesnil et al. (https://github.com/mesnilgr/is13) for our task of extracting opinion targets from reviews.
(2) We used word2vec for learning word embeddings from Amazon.
(3) We used Stanford CoreNLP for part-of-speech tagging on the datasets.

Helpful Commands
================
make convert-senna
make run-rnn dataset=laptop embed=Senna type=elman window=3 nhidden=100 dimension=50 init=false
