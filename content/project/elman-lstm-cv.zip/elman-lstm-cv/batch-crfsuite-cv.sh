for fold in {0..9}
do
    sh run-crfsuite-cv.sh laptop Senna ${fold}
    sh run-crfsuite-cv.sh restaurant Senna ${fold}
done


