#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <iterator>
#include <cassert>
#include <thread>
#include "utils.cpp"

#define uint unsigned int

uint fold = -1;

using namespace std;

void readSentences(vector<vector<string > > &X, vector<vector<string > > &P,
                   vector<vector<string> > &T, string fname) {
  ifstream in(fname.c_str());
  string line;
  vector<string> x;
  vector<string> p;
  vector<string> t; // individual sentences and labels
  while(std::getline(in, line)) {
    if (isWhitespace(line)) {
      if (x.size() != 0) {
        X.push_back(x);
	P.push_back(p);
        T.push_back(t);
        x.clear();
	p.clear();
        t.clear();
      }
    } else {
      string token, part, label;
      uint i = line.find_first_of('\t');
      token = line.substr(0, i);
      uint j = line.find_first_of('\t', i+1);
      part = line.substr(i+1,j-i-1);
      //cout << part << endl;
      i = line.find_last_of('\t');
      label = line.substr(i+1, line.size()-i-1);
      x.push_back(token);
      p.push_back(part);
      t.push_back(label);
    }
  }
  if (x.size() != 0) {
    X.push_back(x);
    P.push_back(p);
    T.push_back(t);
    x.clear();
    p.clear();
    t.clear();
  }
}

void writeDataset(vector<vector<string > > &X, vector<vector<string > > &P,
                   vector<vector<string> > &L, string fname){

  ofstream ofs;
  ofs.open(fname);
  for (uint i = 0; i < X.size(); i++) { // per sentence
    vector<string> tokens = X[i];
    vector<string> tags = P[i];
    vector<string> labels = L[i];
    for (uint j = 0; j < tokens.size(); j++){
      ofs << tokens[j] << "\t" << tags[j] << "\t" << labels[j] << endl;
    }
    ofs << "" << endl;
  }
}
 
int main(int argc, char **argv) {
  string dataset = argv[1];
  fold = atoi(argv[2]); // between 0-9
  srand(135);
  cout << setprecision(6);

  vector<vector<string> > X;
  vector<vector<string> > P;
  vector<vector<string> > T;
  readSentences(X, P, T, dataset+".txt"); // dse.txt or ese.txt

  unordered_map<string, set<uint> > sentenceIds;
  set<string> allDocs;
  ifstream in("sentenceid.txt");
  string line;
  uint numericId = 0;
  while(getline(in, line)) {
    vector<string> s = split(line, ' ');
    assert(s.size() == 3);
    string strId = s[2];

    if (sentenceIds.find(strId) != sentenceIds.end()) {
      sentenceIds[strId].insert(numericId);
    } else {
      sentenceIds[strId] = set<uint>();
      sentenceIds[strId].insert(numericId);
    }
    numericId++;
  }

  vector<vector<string> > trainX, validX, testX;
  vector<vector<string> > trainP, validP, testP;
  vector<vector<string> > trainL, validL, testL;
  vector<bool> isUsed(X.size(), false);

  ifstream in4("datasplit/doclist.mpqaOriginalSubset");
  while(getline(in4, line))
    allDocs.insert(line);

  ifstream in2("datasplit/filelist_train"+to_string(fold));
  while(getline(in2, line)) {
    for (const auto &id : sentenceIds[line]) {
      trainX.push_back(X[id]);
      trainP.push_back(P[id]);
      trainL.push_back(T[id]);
    }
    allDocs.erase(line);
  }
  ifstream in3("datasplit/filelist_test"+to_string(fold));
  while(getline(in3, line)) {
    for (const auto &id : sentenceIds[line]) {
      testX.push_back(X[id]);
      testP.push_back(P[id]);
      testL.push_back(T[id]);
    }
    allDocs.erase(line);
  }

  uint validSize = 0;
  for (const auto &doc : allDocs) {
    for (const auto &id : sentenceIds[doc]) {
      validX.push_back(X[id]);
      validP.push_back(P[id]);
      validL.push_back(T[id]);
    }
  }

  cout << "Total size: " << X.size() << endl;
  cout << "Train size: " << trainX.size() << endl;
  cout << "Valid size: " << validX.size() << endl;
  cout << "Test size: " << testX.size() << endl;
 
  string trainFname = "train" + to_string(fold) + ".tsv";
  string validFname = "valid" + to_string(fold) + ".tsv";
  string testFname = "test" + to_string(fold) + ".tsv";

  writeDataset(trainX, trainP, trainL, trainFname);
  writeDataset(validX, validP, validL, validFname);
  writeDataset(testX, testP, testL, testFname);

  cout << "Train file: " << trainFname << endl;
  cout << "Valid file: " << validFname << endl;
  cout << "Test file: " << testFname << endl;

  return 0;
}
