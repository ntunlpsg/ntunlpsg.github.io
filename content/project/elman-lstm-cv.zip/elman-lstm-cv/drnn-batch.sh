make drnn-dataset dataset=laptop
make run-drnn dataset=laptop embedding=../embeddings/amazon/vectors-50.txt vocabulary=1019782 dim=50 > drnn-lap-amazon-50.log
make run-drnn dataset=laptop embedding=../embeddings/amazon/vectors-300.txt vocabulary=1019782 dim=300 > drnn-lap-amazon-300.log
make run-drnn dataset=laptop embedding=../embeddings/senna/vectors.txt vocabulary=130000 dim=50 > drnn-lap-senna-50.log
make run-drnn dataset=laptop embedding=../embeddings/google-news/GoogleNews-vectors-negative300.txt vocabulary=3000000 dim=300 > drnn-lap-google-300.log

make drnn-dataset dataset=restaurant
make run-drnn dataset=restaurant embedding=../embeddings/amazon/vectors-50.txt vocabulary=1019782 dim=50 > drnn-res-amazon-50.log
make run-drnn dataset=restaurant embedding=../embeddings/amazon/vectors-300.txt vocabulary=1019782 dim=300 > drnn-res-amazon-300.log
make run-drnn dataset=restaurant embedding=../embeddings/senna/vectors.txt vocabulary=130000 dim=50 > drnn-res-senna-50.log
make run-drnn dataset=restaurant embedding=../embeddings/google-news/GoogleNews-vectors-negative300.txt vocabulary=3000000 dim=300 > drnn-res-google-300.log

