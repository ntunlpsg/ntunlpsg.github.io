dataset=$1
embed=$2
dim=$3
hidden=$4

if [ "$embed" == "Google" ]; then
    file=embeddings/google-news/GoogleNews-vectors-negative300.bin.gz
elif [ "$embed" == "Amazon" ]; then
    file=embeddings/amazon/vectors-${dim}.txt
else
    file=embeddings/senna
fi

echo "Dataset:${dataset}, Embedding:${embed}"
echo "========="
for fold in {0..9}
do
    echo "Fold: ${fold}"
    echo "---------"
    cp ${dataset}-elman-${embed}-3-${hidden}-${dim}-${fold}/best.test.txt ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-predict.tsv
    cp ${dataset}/test${fold}.tsv ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-truth.tsv
    sed -i -- 's/ /\t/g' ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-predict.tsv
    sed -i -- 's/B-TERM/B/g' ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-*.tsv
    sed -i -- 's/I-TERM/I/g' ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-*.tsv
    ./deep-recurrent/evaluator ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-predict.tsv ./cv-result/${embed}-${dataset}-${fold}-${dim}-${hidden}-truth.tsv
done

