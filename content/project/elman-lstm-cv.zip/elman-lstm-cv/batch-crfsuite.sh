sh run-crfsuite.sh laptop Senna
sh run-crfsuite.sh laptop Google
sh run-crfsuite.sh laptop Amazon 50
sh run-crfsuite.sh laptop Amazon 300
sh run-crfsuite.sh restaurant Senna
sh run-crfsuite.sh restaurant Google
sh run-crfsuite.sh restaurant Amazon 50
sh run-crfsuite.sh restaurant Amazon 300


